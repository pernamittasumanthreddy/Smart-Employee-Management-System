from django.apps import AppConfig

class RecruitmentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.recruitment'
    verbose_name = 'Enterprise Recruitment & Applicant Tracking (ATS)'
